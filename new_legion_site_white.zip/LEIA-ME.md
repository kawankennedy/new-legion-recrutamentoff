# NEW LEGION — site de recrutamento

Projeto inicial responsivo para a guilda New Legion, com logo fornecida, formulário público e painel privado para aprovar/recusar inscrições.

## O que está pronto neste projeto

- Página responsiva com fundo branco e identidade preta da New Legion.
- Formulário com nick, ID, idade, nível, guerra de guilda, apresentação e Discord opcional.
- Validação de idade 15+, nível 40+ e participação em guerra de guilda.
- Integração com Supabase para gravar as fichas.
- Painel com login, filtros e ações Aprovar / Recusar / Pendente.
- Regras de segurança no banco: público só envia ficha; somente administradores autorizados podem ler e atualizar.

**Importante:** o código não fica online sozinho. É necessário criar/configurar os serviços gratuitos abaixo. Enquanto as chaves não forem configuradas, o site mostra um aviso de configuração e não salva inscrições.

## Passo 1 — Criar o banco e autenticação (Supabase)

1. Entre em https://supabase.com e crie uma conta/projeto gratuito.
2. Dê ao projeto um nome como `new-legion-recrutamento` e defina uma senha forte para o banco. Guarde essa senha.
3. Abra **SQL Editor** no painel do Supabase.
4. Abra o arquivo `supabase/schema.sql` deste projeto, copie todo o conteúdo e execute no SQL Editor.
5. Vá a **Project Settings > API** (ou seção equivalente de chaves) e copie a **Project URL** e a chave pública **anon/publishable**. Nunca coloque a `service_role` ou chave secreta no site.

## Passo 2 — Criar seu acesso de administrador

1. No Supabase, abra **Authentication > Users** e use a opção para adicionar/criar um usuário com seu e-mail e uma senha forte.
2. Copie o UUID/ID desse usuário.
3. No SQL Editor, execute substituindo o texto pelo UUID real:
   `insert into public.admin_users (user_id) values ('COLE-SEU-UUID-AQUI');`
4. Só o usuário cadastrado nessa tabela consegue consultar ou mudar o status das fichas. Não compartilhe seu login.

## Passo 3 — Conectar as chaves ao site

1. Renomeie `.env.example` para `.env` na pasta principal.
2. Preencha:
   - `VITE_SUPABASE_URL` com a Project URL.
   - `VITE_SUPABASE_ANON_KEY` com a chave pública anon/publishable do projeto.
3. Não compartilhe nem publique chaves secretas. A chave pública é apropriada para o navegador somente porque as políticas de segurança do banco (RLS) estão ativadas.

## Passo 4 — Testar no computador

É necessário ter Node.js instalado:
1. Abra um terminal na pasta do projeto.
2. Execute `npm install`
3. Execute `npm run dev`
4. Abra o endereço local mostrado no terminal.
5. Envie uma ficha de teste; depois abra o botão **Painel administrativo**, entre com seu usuário e confirme se a ficha aparece.
6. Teste aprovar e recusar. Confira também que, sem login de administrador, não dá para consultar as fichas.

## Passo 5 — Publicar gratuitamente (Vercel)

1. Crie uma conta em https://vercel.com.
2. Envie o projeto para um repositório GitHub (ou importe o repositório se já estiver no GitHub).
3. Na Vercel, escolha **Add New > Project** e importe o repositório.
4. Em **Environment Variables**, configure `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY`.
5. Publique. A Vercel mostrará um link público que você pode divulgar no Instagram/Discord.
6. Se mudar variáveis depois, faça redeploy para aplicá-las.

## Observações importantes

- Os planos gratuitos têm limites e regras que podem mudar; confira os painéis oficiais.
- Este starter não envia notificações automáticas por WhatsApp/e-mail; você consulta o painel.
- Não peça senha do Free Fire nem dados pessoais desnecessários. O ID e o nick do jogo bastam para identificar o candidato.
- Se quiser permitir envio por menores de idade, pense em privacidade e obtenha os consentimentos apropriados quando aplicável.
- A aprovação no painel altera o status da ficha, mas não adiciona o jogador automaticamente à guilda dentro do Free Fire.
