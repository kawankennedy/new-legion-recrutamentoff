-- Execute este SQL no SQL Editor do seu projeto Supabase.
create table if not exists public.applications (
  id uuid primary key default gen_random_uuid(),
  nickname text not null check (char_length(nickname) between 1 and 40),
  player_id text not null check (char_length(player_id) between 1 and 25),
  age integer not null check (age >= 15 and age <= 99),
  level integer not null check (level >= 40 and level <= 100),
  guild_war boolean not null default false,
  about text not null check (char_length(about) between 1 and 300),
  discord text,
  status text not null default 'pendente' check (status in ('pendente','aprovada','recusada')),
  created_at timestamptz not null default now()
);

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.applications enable row level security;
alter table public.admin_users enable row level security;

-- Função de verificação para políticas RLS, sem recursão na tabela admin_users.
create or replace function public.is_new_legion_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.admin_users
    where user_id = (select auth.uid())
  );
$$;

revoke all on function public.is_new_legion_admin() from public;
grant execute on function public.is_new_legion_admin() to authenticated;

-- Público pode apenas enviar ficha; não pode ler nem modificar inscrições.
drop policy if exists "Anyone can submit an application" on public.applications;
create policy "Anyone can submit an application"
on public.applications for insert
to anon, authenticated
with check (
  status = 'pendente'
  and age >= 15
  and level >= 40
  and guild_war = true
);

-- Apenas contas cadastradas como administradoras podem consultar/gerenciar fichas.
drop policy if exists "Admins can read applications" on public.applications;
create policy "Admins can read applications"
on public.applications for select
to authenticated
using (public.is_new_legion_admin());

drop policy if exists "Admins can update applications" on public.applications;
create policy "Admins can update applications"
on public.applications for update
to authenticated
using (public.is_new_legion_admin())
with check (public.is_new_legion_admin());

-- Bloqueia acesso público à lista de administradores.
drop policy if exists "Admins can read admin list" on public.admin_users;
create policy "Admins can read admin list"
on public.admin_users for select
to authenticated
using (public.is_new_legion_admin());

-- Após criar sua conta em Authentication > Users, copie o UUID dela e execute:
-- insert into public.admin_users (user_id) values ('COLE-SEU-UUID-AQUI');
